Thanks for downloading this template!

Template Name: Blogy
Template URL: https://bootstrapmade.com/blogy-bootstrap-blog-template/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/
